#ifndef CHESSSQUARE_H
#define CHESSSQUARE_H


class ChessSquare
{
public:
    ChessSquare();
    int squareColor;
    bool isEmpty;
    int figureType;
    int figureColor;
};

#endif // CHESSSQUARE_H
